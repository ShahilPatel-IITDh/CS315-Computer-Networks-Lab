import socket
import threading
import json
import time

class Manager:
    def __init__(self, ip, port, broadcast_interval=10):
        self.ip = ip
        self.port = port
        self.active_peers = {}
        self.lock = threading.Lock()
        self.broadcast_interval = broadcast_interval

    def add_peer(self, addr, peer_port):
        with self.lock:
            self.active_peers[(addr, peer_port)] = peer_port
            print(f"Added peer: {addr}:{peer_port}")

    def remove_peer(self, addr, peer_port):
        with self.lock:
            del self.active_peers[(addr, peer_port)]
            print(f"Removed peer: {addr}:{peer_port}")

    def broadcast_peers(self):
        with self.lock:
            print("Broadcasting active peers list")
            for (addr, peer_port), _ in self.active_peers.items():
                try:
                    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                        s.connect((addr, peer_port))
                        s.sendall(json.dumps({"peers": list(self.active_peers.keys())}).encode())
                except socket.error:
                    pass

    def handle_connection(self, conn, addr):
        try:
            data = conn.recv(1024)
            if data:
                request = json.loads(data.decode())
                if request["type"] == "join":
                    self.add_peer(addr[0], request["port"])
                elif request["type"] == "leave":
                    self.remove_peer(addr[0], request["port"])
        finally:
            conn.close()

    def start(self):
        print("Starting manager...")
        broadcast_thread = threading.Thread(target=self.periodic_broadcast)
        broadcast_thread.start()

        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind((self.ip, self.port))
            s.listen()
            while True:
                conn, addr = s.accept()
                t = threading.Thread(target=self.handle_connection, args=(conn, addr))
                t.start()

    def periodic_broadcast(self):
        while True:
            time.sleep(self.broadcast_interval)
            self.broadcast_peers()

if __name__ == "__main__":
    manager = Manager("127.0.0.1", 5000)
    manager.start()
